// JavaScript Document
$(function() {
var ticker = $("#ticker1");
var ticker2 = $("#ticker2");
var ticker3 = $("#ticker3");
var tickerfour = $("#tickerfour");

function animator(currentItem) {
var distance = currentItem.height();
duration = (distance + parseInt(currentItem.css("marginTop"))) / 0.025;
currentItem.animate({ marginTop: -distance }, duration, "linear", function() {
currentItem.appendTo(currentItem.parent()).css("marginTop", 0);
animator(currentItem.parent().children(":first"));
}); 
};

animator(ticker.children(":first"));
var j=0		
$('#stop').click(function() {

ticker.children().stop();
j=1
$('#stop').hide();
$('#play').show();

$("#ticker1").css("overflow", "scroll");
$("#ticker1 li").addClass("stopped");

});


ticker.mouseenter(function() {
ticker.children().stop();
});

$('#play').click(function() {
animator(ticker.children(":first"));
j=0;
$('#stop').show();
$('#play').hide();
$("#ticker1").css("overflow", "hidden");
$("#ticker1 li").removeClass('stopped');
$("#ticker1 li").addClass('aaa');
$("#ticker1 li").removeProp("margin-top");
});

ticker.mouseleave(function() {
if(j == 0)
animator(ticker.children(":first"));
});





ticker2.children().filter("ul").each(function() {
var dt = $(this),
container = $("<div>");
dt.next().appendTo(container);
dt.prependTo(container);
container.appendTo(ticker2);
});
ticker2.css("overflow", "hidden");



animator(ticker2.children(":first"));
var k=0	
$('#stop2').click(function() {
ticker2.children().stop();
k=1
$('#stop2').hide();
$('#play2').show();

$("#ticker2").css("overflow", "scroll");
$("#ticker2 li").addClass("stopped");

});


ticker2.mouseenter(function() {
ticker2.children().stop();
});

$('#play2').click(function() {
animator(ticker2.children(":first"));
k=0
$('#stop2').show();
$('#play2').hide();

$("#ticker2").css("overflow", "hidden");
$("#ticker2 li").removeClass("stopped");

});

ticker2.mouseleave(function() {
if(k == 0)
animator(ticker2.children(":first"));
});

/*=======================*/

ticker3.children().filter("ul").each(function() {
var dt = $(this),
container = $("<div>");
dt.next().appendTo(container);
dt.prependTo(container);
container.appendTo(ticker3);
});
ticker3.css("overflow", "hidden");



animator(ticker3.children(":first"));
var l=0	
$('#stop3').click(function() {
ticker3.children().stop();
l=1
$('#stop3').hide();
$('#play3').show();

$("#ticker3").css("overflow", "scroll");
$("#ticker3 li").addClass("stopped");

});


ticker3.mouseenter(function() {
ticker3.children().stop();
});

$('#play3').click(function() {
animator(ticker3.children(":first"));
l=0
$('#stop3').show();
$('#play3').hide();

$("#ticker3").css("overflow", "hidden");
$("#ticker3 li").removeClass("stopped");

});

ticker3.mouseleave(function() {
if(l == 0)
animator(ticker3.children(":first"));
});
/*============================================*/
tickerfour.children().filter("ul").each(function() {
var dt = $(this),
container = $("<div>");
dt.next().appendTo(container);
dt.prependTo(container);
container.appendTo(tickerfour);
});
tickerfour.css("overflow", "hidden");



animator(tickerfour.children(":first"));
var l=0	
$('#stop4').click(function() {
tickerfour.children().stop();
l=1
$('#stop4').hide();
$('#play4').show();

$("#tickerfour").css("overflow", "scroll");
$("#tickerfour li").addClass("stopped");

});


tickerfour.mouseenter(function() {
tickerfour.children().stop();
});

$('#play4').click(function() {
animator(tickerfour.children(":first"));
l=0
$('#stop4').show();
$('#play4').hide();

$("#tickerfour").css("overflow", "hidden");
$("#tickerfour li").removeClass("stopped");

});

tickerfour.mouseleave(function() {
if(l == 0)
animator(tickerfour.children(":first"));
});

/*=============================================*/
});
