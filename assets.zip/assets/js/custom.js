 jQuery(document).ready(function ($) {
			 
			  $('.numberonly').keypress(function (e) {    
		  var specialKeys = new Array();
          specialKeys.push(8);
          specialKeys.push(13);
              var keyCode = (e.which) ? e.which : event.keyCode    
           var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
           //alert($(this).val());
            if(ret){
            $(this).next("span").remove();
            }else{
              $(this).next("span").remove();
            $(this).after('<span style="color: Red;" >* Input digits (0 - 9)</span>')
            }
              return ret; 
        }); 

            $('.alphabetonly').keypress(function (e) {  
             var specialKeys = new Array();
             specialKeys.push(8);
              var keyCode = (e.which) ? e.which : event.keyCode  
             // alert(keyCode);  
           var ret = ((keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || (keyCode == 32) ||specialKeys.indexOf(keyCode) != -1);
           //alert($(this).val());
            if(ret){
            $(this).next("span").remove();
            }else{
              $(this).next("span").remove();
            $(this).after('<span style="color: Red;" >* Input Alphabets (A - Z, a-z)</span>')
            }
              return ret; 
        });
			 
			 
			 $('#Select1').change(function(){
             var path=$(this).val();
             // alert(path);
              if(path!='#'){
              window.location.href='<?=base_url()?>'+path;

                 }
          });
			 
			 
		  $('#Select2').change(function(){
             var path=$(this).val();
             // alert(path);
              if(path!='#'){
              window.location.href='<?=base_url()?>'+path;

                 }
          });


var lancode='<?=$lan_code?>';

$("#videosearch").change(function(){

 if($(this).val()!=''){
  $("#videoformsearch").submit();
}
});
		
	
$("#audiosearch").change(function(){

 if($(this).val()!=''){
  $("#audioformsearch").submit();
}
});	


$("#imagsearch").change(function(){

 if($(this).val()!=''){
  $("#imggallerysearch").submit();
}
});
			 

$("#change_lan").change(function(){
    var activelan='<?=$lan_code;?>';
    var isindex='<?=!empty($index)?$index:''?>';
    if(isindex=='indexpage'){
    var path='welcome/setLanguageCode';
    }else{
       var path='setLanguageCode'; 
        
    }
   //alert(path);
    //return false;
     
    var lanval=$(this).val();
    if(activelan!=lanval){
    if(lanval!=''){
        $.ajax({
            
          type:'post',
          url:path,
          data:{'lan_code':lanval}, 
          success:function(data){
              //alert(data);
              window.location.reload();
              
              
              
          },
          error:function(err){
              
              //alert(err);
          }
            
         })
        
    }
        
    }else{
        
        
        
    }
    
    //alert(lanval);
    
    
});		


$("#btncomment").click(function(){
var err=0;
if($("#cname").val()==''){
   $("#cname").addClass("error"); 
   err++;
}else{
     $("#cname").removeClass("error"); 
}

if($("#cemail").val()==''){
   $("#cemail").addClass("error"); 
   err++;
}else{
     $("#cemail").removeClass("error"); 
}


if($("#ccomment").val()==''){
   $("#ccomment").addClass("error"); 
   err++;
}else{
     $("#ccomment").removeClass("error"); 
}

if(err==0){
    
                 
                  $.ajax({
        url: '<?php echo base_url()?>/Welcome/savecomment',
        type: 'POST',
        data: {'name':$("#cname").val(),'email':$("#cemail").val(),'comment':$("#ccomment").val(),'blogid':$("#blogid").val()},
        success: function (data) {
            // alert(data);
			var lan='<?=$lan_code;?>';
            if(data==1){
				if(lancode=='EN')
				{
                 swal("Success!", "Submitted Successfully !!", "success");
				}else{
					
					swal("सफल !", "आपकी टिप्पणी सफलतापूर्वक सबमिट की गई !!", "success");
				}
                
            }else if(data==2){
				if(lancode=='EN')
				{
                 swal("Failed!", "Some Technical Problem Accured !!", "error");
				}else{
				  swal("असफल !", "कुछ तकनीकी समस्या ठीक हुई !!", "error");	
				}
            }else{
                $(".alert-dismissable").hide();
            }
             $("#commentform").trigger("reset");
           // $("#").reset();
        },
      
    });     
                   
                   
                   
                   
}else{
	if(lancode=='EN')
				{
   swal("Failed!", "Please Fill All Highlighed Fields !!", "error");
				}else{
	swal("असफल !", "कृपया सभी हाइलाइट किए गए फ़ील्ड भरें !!", "error");				
				}
     return false; 
    
}

});




			 
  $("#askmeform").submit(function(e) {
  e.preventDefault();    
    var formData = new FormData(this);
    var err=0;
 
   if(formData.get('aname')==''){ 
        err++;
          $("#aname").addClass('error');

   }else{
            $("#aname").removeClass('error');
   }

    if(formData.get('agender')==''){
        err++;
          $("#agender").addClass('error');

   }else{
            $("#agender").removeClass('error');
   }



     if(formData.get('aage')==''){
   err++;
  $("#aage").addClass('error');

     }else{
  $("#aage").removeClass('error');
      }

if(formData.get('adistrict')==''){
   err++;
  $("#adistrict").addClass('error');

     }else{
  $("#adistrict").removeClass('error');
      }


      if(formData.get('aemail')==''){
   err++;
  $("#aemail").addClass('error');

     }else{
  $("#aemail").removeClass('error');
      }



      if(formData.get('acontact')==''){
   err++;
  $("#acontact").addClass('error');

     }else{
  $("#acontact").removeClass('error');       
      }


      if(formData.get('aquery')==''){
   err++;
  $("#aquery").addClass('error');

     }else{
  $("#aquery").removeClass('error');       
      }
      
 if(err==0){
          
    //alert(formData);
    $.ajax({
        url: '<?php echo base_url()?>/Welcome/askme',
        type: 'POST',
        data: formData,
        success: function (data) {
             //alert(data);
            if(data==1){
				if(lancode=='EN')
				{
                 swal("Success!", "Your Query Registered Successfully !!", "success");
				}else{
					swal("सफल!", "आपकी क्वेरी सफलतापूर्वक पंजीकृत हो गई !!", "success");
				}
                
            }else if(data==2){
				if(lancode=='EN')
				{
                 swal("Failed!", "Some Technical Problem Accured !!", "error");
				}else{
					swal("असफल !", "कुछ तकनीकी समस्या हुई !!", "error");
				}
            }else if(data==3){
				if(lancode=='EN')
				{
                 swal("Info!", "Your Are Registered Already !!", "info");
				}else{
					swal("जानकारी !", "आपका पंजीकरण पहले से ही है !!", "info");
				}
            }else{
                $(".alert-dismissable").hide();
            }
             $("#askmeform").trigger("reset");
           // $("#").reset();
        },
        cache: false,
        contentType: false,
        processData: false
    });
}else{
	if(lancode=='EN')
	 {
     swal("Failed!", "Please Fill All Highlighed Fields !!", "error");
	 }else{
		  swal("असफल !", "कृपया सभी हाइलाइट किए गए फ़ील्ड भरें !!", "error");
	 }
     return false;
   }

    });  

			 
			 
			 
			 
 $("#grivianceform").submit(function(e) {
  e.preventDefault();    
    var formData = new FormData(this);
    var err=0;
 
   if(formData.get('gname')==''){ 
        err++;
          $("#gname").addClass('error');

   }else{
            $("#gname").removeClass('error');
   }

    if(formData.get('ggender')==''){
        err++;
          $("#ggender").addClass('error');

   }else{
            $("#ggender").removeClass('error');
   }

     if(formData.get('gcontact')==''){
   err++;
  $("#gcontact").addClass('error');

     }else{
  $("#gcontact").removeClass('error');
      }

if(formData.get('gemail')==''){
   err++;
  $("#gemail").addClass('error');

     }else{
  $("#gemail").removeClass('error');
      }


      if(formData.get('gpincode')==''){
   err++;
  $("#gpincode").addClass('error');

     }else{
  $("#gpincode").removeClass('error');
      }



      if(formData.get('gdistrict')==''){
   err++;
  $("#gdistrict").addClass('error');

     }else{
  $("#gdistrict").removeClass('error');       
      }


      if(formData.get('gaddress')==''){
   err++;
  $("#gaddress").addClass('error');

     }else{
  $("#gaddress").removeClass('error');       
      }



      if(formData.get('gcomplane')==''){
   err++;
  $("#gcomplane").addClass('error');

     }else{
  $("#gcomplane").removeClass('error');       
      }

  if(formData.get('gsubject')==''){
   err++;
  $("#gsubject").addClass('error');

     }else{
  $("#gsubject").removeClass('error');       
      }


  if(formData.get('gcomplain')==''){
   err++;
  $("#gcomplain").addClass('error');

     }else{
  $("#gcomplain").removeClass('error');       
      }







 if(err==0){ 
          
    //alert(formData);
    $.ajax({
        url: '<?php echo base_url()?>/Welcome/grievances',
        type: 'POST',
        data: formData,
        success: function (data) {
             //alert(data);
            if(data==1){
				if(lancode=="EN"){
                 swal("Success!", "Your Grievances Registered Successfully !!", "success");
                }else{
				swal("सफल !", "आपकी शिकायतें सफलतापूर्वक दर्ज की गईं !!", "success");	
				}
                
            }else if(data==2){
					if(lancode=="EN")
					{
                     swal("Failed!", "Some Technical Problem Accured !!", "error");
					}else{
						swal("असफल !", "कुछ तकनीकी समस्या हुई !!", "error");
					 }
            }else if(data==3){
				if(lancode=="EN")
					{
                 swal("Info!", "Your Are Registered Already !!", "info");
					}else{
						  swal("जानकारी !", "आपका पंजीकरण पहले से ही है !!", "info");
					} 
            }else{
                $(".alert-dismissable").hide();
            }
             $("#grivianceform").trigger("reset");
           // $("#").reset();
        },
        cache: false,
        contentType: false,
        processData: false
    });
}else{
	if(lancode=="EN")
	{
     swal("Failed!", "Please Fill All Highlighed Fields !!", "error");
	}else{
		swal("असफल !", "कृपया सभी हाइलाइट किए गए फ़ील्ड भरें !!", "error");
	}
     return false;
   }

    });    
       
			 
			$("#feedbackform").submit(function(e) {
  e.preventDefault();    
    var formData = new FormData(this);
    var err=0;
 
   if(formData.get('fname')==''){ 
        err++;
          $("#fname").addClass('error');

   }else{
            $("#fame").removeClass('error');
   }

    if(formData.get('fto')==''){
        err++;
          $("#fto").addClass('error');

   }else{
            $("#fto").removeClass('error');
   }

     if(formData.get('femail')==''){
   err++;
  $("#femail").addClass('error');

     }else{
  $("#femail").removeClass('error');
      }

if(formData.get('femail')==''){
   err++;
  $("#femail").addClass('error');

     }else{
  $("#femail").removeClass('error');
      }


      if(formData.get('faddress')==''){
   err++;
  $("#faddress").addClass('error');

     }else{
  $("#faddress").removeClass('error');
      }



      if(formData.get('ftelephone')==''){
   err++;
  $("#ftelephone").addClass('error');

     }else{
  $("#ftelephone").removeClass('error');       
      }


      if(formData.get('ffax')==''){
   err++;
  $("#ffax").addClass('error');

     }else{
  $("#ffax").removeClass('error');       
      }



      if(formData.get('fsuggestion')==''){
   err++;
  $("#fsuggestion").addClass('error');

     }else{
  $("#fsuggestion").removeClass('error');       
      }
 if(err==0){
          
    //alert(formData);
    $.ajax({
        url: '<?php echo base_url()?>/Welcome/feedback',
        type: 'POST',
        data: formData,
        success: function (data) {
             //alert(data);
            if(data==1){
				if(lancode=="EN"){
                 swal("Success!", "Your Feedback Registered Successfully !!", "success");
				}else{
					
					 swal("सफल !", "आपकी प्रतिक्रिया सफलतापूर्वक दर्ज की गई !!", "success");
				}
                
            }else if(data==2){
				if(lancode=="EN"){
                 swal("Failed!", "Some Technical Problem Accured !!", "error");
				}else{
					swal("असफल !", "कुछ तकनीकी समस्या हुई !!", "error");
				}
            }else if(data==3){
				if(lancode=="EN"){
                 swal("Info!", "Your Are Registered Already !!", "info");
				}else{
					swal("जानकारी !", "आपका पंजीकरण पहले से ही है  !!", "info");
				}
            }else{
                $(".alert-dismissable").hide();
            }
             $("#feedbackform").trigger("reset");
           // $("#").reset();
        },
        cache: false,
        contentType: false,
        processData: false
    });
}else{
	if(lancode=="EN"){
     swal("Failed!", "Please Fill All Highlighed Fields !!", "error");
	}else{
		swal("असफल !", "कृपया सभी हाइलाइट किए गए फ़ील्ड भरें !!", "error");
	}
     return false;
   }

    });		 
			 
			 
			 
			 $("#deregister").click(function(){

             var mobile= $("#err_mobile").val();
             //alert(mobile);
             if(mobile!=''){
        $("#err_mobile").removeClass('error');
          
             $.ajax({
        url: '<?php echo base_url()?>/Welcome/deregistration',
        type: 'POST',
        data: {'mobile':mobile},
        success: function (data) {
             //alert(data);
            if(data==1){
				if(lancode=="EN"){
                 swal("Success!", "Your Are  Successfully Deregistered!!", "success");
                }else{
					swal("सफल !", "आपका सफलतापूर्वक पंजीकरण रद्द कर दिया गया है !!", "success");
				}
                
            }else if(data==2){
				if(lancode=="EN"){
                 swal("Info!", "Your Are  Already Deregistered !!", "info");
				}else{
					swal("जानकारी!", "आपका पहले से ही पंजीकृत नहीं है  !!", "info");
					
				}
            }else if(data==3){
				if(lancode=="EN"){
                 swal("Info!", "Your Are Not Registered!!", "info");
				}else{
					   swal("जानकारी!", "आप पंजीकृत नहीं हैं !!", "info");
				}
            }else if(data==4){
				if(lancode=="EN"){
                 swal("Failed!", "Your Are  Successfully Deregistered!!", "error");
				}else{
					 swal("असफल !", "आप सफलतापूर्वक अपंजीकृत नहीं हुये !!", "error");
					
				}
            }else{
                $(".alert-dismissable").hide();
            }
             $("#registerdata").trigger("reset");
           // $("#").reset();
        },
         
    });
             
             
          }else{
           
            $("#err_mobile").addClass('error');
          if($lancode=="EN"){
             swal("Failed!", "Please Fill All Highlighed Fields !!", "error");
		  }else{
			  
			  swal("असफल !", "कृपया सभी हाइलाइट किए गए फ़ील्ड भरें !!", "error");
		  }
            
           }

      


       });
			 
			 
			 
			 
			 
			 
			 
			 
//$(".alert-dismissable").hide();
$("#registerdata").submit(function(e) {
  e.preventDefault();    
    var formData = new FormData(this);
    var err=0;

   if(formData.get('mobile')==''){
        err++;
          $("#err_mobile").addClass('error');

   }else{
            $("#err_mobile").removeClass('error');
   }

    if(formData.get('age')==''){
        err++;
          $("#err_age").addClass('error');

   }else{
            $("#err_age").removeClass('error');
   }

     if(formData.get('city')==''){
   err++;
  $("#err_city").addClass('error');

     }else{
  $("#err_city").removeClass('error');
      }


if(err==0){
          
    //alert(formData);
    $.ajax({
        url: '<?php echo base_url()?>/Welcome/registration',
        type: 'POST',
        data: formData,
        success: function (data) {
             //alert(data);
            if(data==1){
				if(lancode=="EN"){
                 swal("Success!", "Your Are Registered Successfully !!", "success");
				}else{
					swal("सफल !", "आप सफलतापूर्वक पंजीकृत हैं !!", "success");
				}
                
            }else if(data==2){
				if(lancode=="EN"){
                 swal("Failed!", "Some Technical Problem Accured !!", "error");
				}else{
					 swal("असफल!", "कुछ तकनीकी समस्या हुई !!", "error");
				}
            }else if(data==3){
				if(lancode=="EN"){
                 swal("Info!", "Your Are Registered Already !!", "info");
				}else{
					 swal("जानकारी !", "आपका पंजीकरण पहले से ही है !!", "info");
				}
            }else{
                $(".alert-dismissable").hide();
            }
             $("#registerdata").trigger("reset");
           // $("#").reset();
        },
        cache: false,
        contentType: false,
        processData: false
    });
}else{
	if(lancode=="EN"){
     swal("Failed!", "Please Fill All Highlighed Fields !!", "error");
	}else{
		  swal("असफल !", "कृपया सभी हाइलाइट किए गए फ़ील्ड भरें !!", "error");
	}
     return false;
   }

    });
			 
			 
			 
			 
             $('.my-news-ticker').AcmeTicker({
                 type:'marquee',/*horizontal/horizontal/Marquee/type*/
                 direction: 'left',/*up/down/left/right*/
                 speed: 0.05,/*true/false/number*/ /*For vertical/horizontal 600*//*For marquee 0.05*//*For typewriter 50*/
                 controls: {
                     toggle: $('.acme-news-ticker-pause'),/*Can be used for horizontal/horizontal/typewriter*//*not work for marquee*/
                 }
             });
         });