(function($) {
    'use strict';
    $(function() {



        var mon_01 = $('#mon_0').val();
        var mon_02 = $('#mon_1').val();
        var mon_03 = $('#mon_2').val();
        var mon_04 = $('#mon_3').val();
        var mon_05 = $('#mon_4').val();
        var mon_06 = $('#mon_5').val();

        var mon_07 = $('#mon_6').val();
        var mon_08 = $('#mon_7').val();
        var mon_09 = $('#mon_8').val();
        var mon_10 = $('#mon_9').val();
        var mon_11 = $('#mon_10').val();
        var mon_12 = $('#mon_11').val();



    if ($("#orders-chart").length) {

        var mon_01_req = $('#req_0').val();
        var mon_02_req = $('#req_1').val();
        var mon_03_req = $('#req_2').val();
        var mon_04_req = $('#req_3').val();
        var mon_05_req = $('#req_4').val();
        var mon_06_req = $('#req_5').val();
        var mon_07_req = $('#req_6').val();
        var mon_08_req = $('#req_7').val();
        var mon_09_req = $('#req_8').val();
        var mon_10_req = $('#req_9').val();
        var mon_11_req = $('#req_10').val();
        var mon_12_req = $('#req_11').val();




      var currentChartCanvas = $("#orders-chart").get(0).getContext("2d");
      var currentChart = new Chart(currentChartCanvas, {
        type: 'bar',
        data: {
          labels: [mon_12,mon_11, mon_10, mon_09, mon_08, mon_07, mon_06, mon_05, mon_04, mon_03, mon_02, mon_01],
          datasets: [{
              label: 'Orders',
              data: [mon_12_req, mon_11_req, mon_10_req, mon_09_req, mon_08_req, mon_07_req, mon_06_req, mon_05_req, mon_04_req, mon_03_req, mon_02_req, mon_01_req],
              backgroundColor: '#392c70'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          layout: {
            padding: {
              left: 0,
              right: 0,
              top: 20,
              bottom: 0
            }
          },
          scales: {
            yAxes: [{
              gridLines: {
                drawBorder: true,
              },
              ticks: {
                stepSize: 250,
                fontColor: "#686868"
              }
            }],
            xAxes: [{
              stacked: true,
              ticks: {
                beginAtZero: true,
                fontColor: "#686868"
              },
              gridLines: {
                display: true,
              },
              barPercentage: 0.4
            }]
          },
          legend: {
            display: false
          },
          elements: {
            point: {
              radius: 0
            }
          },
          legendCallback: function(chart) { 
            var text = [];
            text.push('<ul class="legend'+ chart.id +'">');
            for (var i = 0; i < chart.data.datasets.length; i++) {
              text.push('<li><span class="legend-label" style="background-color:' + chart.data.datasets[i].backgroundColor + '"></span>');
              if (chart.data.datasets[i].label) {
                text.push(chart.data.datasets[i].label);
              }
              text.push('</li>');
            }
            text.push('</ul>');
            return text.join("");
          },
        }
      });
      document.getElementById('orders-chart-legend').innerHTML = currentChart.generateLegend();
    }



    if ($('#sales-chart').length) {

        var mon_01_sel = $('#sel1_0').val();
        var mon_02_sel = $('#sel1_1').val();
        var mon_03_sel = $('#sel1_2').val();
        var mon_04_sel = $('#sel1_3').val();
        var mon_05_sel = $('#sel1_4').val();
        var mon_06_sel = $('#sel1_5').val();
        var mon_07_sel = $('#sel1_6').val();
        var mon_08_sel = $('#sel1_7').val();
        var mon_09_sel = $('#sel1_8').val();
        var mon_10_sel = $('#sel1_9').val();
        var mon_11_sel = $('#sel1_10').val();
        var mon_12_sel = $('#sel1_11').val();





      var lineChartCanvas = $("#sales-chart").get(0).getContext("2d");
      var data = {
        labels: [mon_12,mon_11, mon_10, mon_09, mon_08, mon_07, mon_06, mon_05, mon_04, mon_03, mon_02, mon_01],
        datasets: [
          {
            label: 'Sales',
            data: [mon_12_sel, mon_11_sel, mon_10_sel, mon_09_sel, mon_08_sel, mon_07_sel, mon_06_sel, mon_05_sel, mon_04_sel, mon_03_sel, mon_02_sel, mon_01_sel],
            borderColor: [
              '#392c70'
            ],
            borderWidth: 3,
            fill: true
          }
        ]
      };
      var options = {
        scales: {
          yAxes: [{
            gridLines: {
              drawBorder: false
            },
            ticks: {
              stepSize: 2000,
              fontColor: "#686868"
            }
          }],
          xAxes: [{
            display: true,
            gridLines: {
              drawBorder: true
            }
          }]
        },
        legend: {
          display: false
        },
        elements: {
          point: {
            radius: 3
          }
        },
        stepsize: 1
      };
      var lineChart = new Chart(lineChartCanvas, {
        type: 'line',
        data: data,
        options: options
      });
    }
    if ($("#sales-status-chart").length) {


      let pending = $('#pending').val();
      let delivered = $('#delivered').val();
      let shipped = $('#shipped').val();
      let cancelled = $('#cancelled').val();

      var pieChartCanvas = $("#sales-status-chart").get(0).getContext("2d");
      var pieChart = new Chart(pieChartCanvas, {
        type: 'pie',
        data: {
          datasets: [{
           data: [pending, shipped, cancelled, delivered],
            backgroundColor: [
              '#392c70',
              '#F5A623',
              '#ff5e6d',
              '#04b76b',
            ],
            borderColor: [
              '#392c70',
              '#F5A623',
              '#ff5e6d',
              '#04b76b',
            ],
          }],
      
          // These labels appear in the legend and in the tooltips when hovering different arcs
          labels: [
            'Pending',
            'Shipped',
            'Cancelled',
            'Delivered',
          ]
        },
        options: {
          responsive: true,
          animation: {
            animateScale: true,
            animateRotate: true
          },
          legend: {
            display: false
          },
          legendCallback: function(chart) { 
            var text = [];
            text.push('<ul class="legend'+ chart.id +'">');
            for (var i = 0; i < chart.data.datasets[0].data.length; i++) {
              text.push('<li><span class="legend-label" style="background-color:' + chart.data.datasets[0].backgroundColor[i] + '"></span>');
              if (chart.data.labels[i]) {
                text.push(chart.data.labels[i]);
              }
              text.push('<label class="badge badge-light badge-pill legend-percentage ml-auto">'+ chart.data.datasets[0].data[i] + '%</label>');
              text.push('</li>');
            }
            text.push('</ul>');
            return text.join("");
          }
        }
      });
      document.getElementById('sales-status-chart-legend').innerHTML = pieChart.generateLegend();
    }
    if ($("#daily-sales-chart").length) {
      var dailySalesChartData = {
        datasets: [{
          data: [50, 10, 10, 30],
          backgroundColor: [
            '#392c70',
            '#04b76b',
            '#e9e8ef',
            '#ff5e6d'
          ],
          borderWidth: 0
        }],
    
        // These labels appear in the legend and in the tooltips when hovering different arcs
        labels: [
          'Mail order sales',
          'Instore sales',
          'Download sales',
          'Sales return'
        ]
      };
      var dailySalesChartOptions = {
        responsive: true,
        maintainAspectRatio: true,
        animation: {
          animateScale: true,
          animateRotate: true
        },
        legend: {
          display: false
        },
        legendCallback: function(chart) { 
          var text = [];
          text.push('<ul class="legend'+ chart.id +'">');
          for (var i = 0; i < chart.data.datasets[0].data.length; i++) {
            text.push('<li><span class="legend-label" style="background-color:' + chart.data.datasets[0].backgroundColor[i] + '"></span>');
            if (chart.data.labels[i]) {
              text.push(chart.data.labels[i]);
            }
            text.push('</li>');
          }
          text.push('</ul>');
          return text.join("");
        },
        cutoutPercentage: 70     
      };
      var dailySalesChartCanvas = $("#daily-sales-chart").get(0).getContext("2d");
      var dailySalesChart = new Chart(dailySalesChartCanvas, {
        type: 'doughnut',
        data: dailySalesChartData,
        options: dailySalesChartOptions
      });
      document.getElementById('daily-sales-chart-legend').innerHTML = dailySalesChart.generateLegend();
    }
    if ($("#inline-datepicker-example").length) {
      $('#inline-datepicker-example').datepicker({
        enableOnReadonly: true,
        todayHighlight: true,
      });
    }
  });
})(jQuery);